 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigInteger;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author Dishant Mittal
 */

@WebServlet(name = "Palin",
        urlPatterns = {"/Palin"})
public class Palin extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet T1Servlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet T1Servlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String ua = request.getHeader("User-Agent");

        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }

         String inputstring = request.getParameter("inputstring");
         if(inputstring != null) {
             
        request.setAttribute("ipstring", inputstring); //To display back the user input
         
         /*
          Removes all punctuations from the string.
         */
         String checkstring = inputstring.replaceAll("[^A-Za-z0-9]", "");
         
         
         /*
         Checks if string is not emplty then converts the whole string to loewrcase for comparison.
         */
         if(checkstring.length() != 0) {
             checkstring = checkstring.toLowerCase();
         }
         /*
         Reverses the string.
         */
         String reverse = (new StringBuffer(checkstring).reverse()).toString();
         
         /*
         Checks if the string, after removing numbers and punctuations and converting it to lowercase, is equal to its reverse.
         */
         if(checkstring.equals(reverse)) {
             request.setAttribute("result", " is a palindrome.");
         }
         else {
             request.setAttribute("result", " is not a palindrome.");
         }
         
         RequestDispatcher view = request.getRequestDispatcher("result.jsp");
         view.forward(request, response);
         }
         else {
              RequestDispatcher view = request.getRequestDispatcher("index.jsp");
         view.forward(request, response);
         }
         
    } // End of void doGet
    
     
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
