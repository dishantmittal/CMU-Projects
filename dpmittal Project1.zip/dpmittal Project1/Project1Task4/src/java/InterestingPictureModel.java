

/*
 * @author Joe Mertz
 * 
 * This file is the Model component of the MVC, and it models the business
 * logic for the web application.  In this case, the business logic involves
 * making a request to flickr.com and then screen scraping the HTML that is
 * returned in order to fabricate an image URL.
 */
import static com.sun.corba.se.spi.presentation.rmi.StubAdapter.request;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;
import javax.servlet.RequestDispatcher;
import java.util.logging.*;
import java.util.logging.Level;



public class InterestingPictureModel {

    private String pictureTag; // The search string of the desired picture
    private String pictureURL = ""; // The URL of the picture image
    private String pictureWidth, pictureHeight;
    private final static Logger LOGGER = Logger.getLogger(InterestingPictureModel.class.getName()); // To decode the errors in the code
    /**
     * Arguments.
     *
     * @param searchTag The tag of the photo to be searched for.
     */
    public void doICAASearch(String searchTag) {
        pictureTag = searchTag;

        // Create a URL for the desired page
        String icaaURL = "http://digital.library.illinoisstate.edu/cdm/search/searchterm/" + searchTag + "*/field/subjec/mode/exact/conn/and/order/nosort";
        String response = fetch(icaaURL);

        //System.out.println(response);

        /*
         * Find the picture URL to scrape
         *
         * Screen scraping is an art that requires looking at the HTML
         * that is returned creatively and figuring out how to cut out
         * the data that is important to you.
         */
       int cutLeft = response.indexOf("id=\"cdm_results_list\"");
        
        // If list is empty it means search did not return any result for that pattern
       /* 
       if (cutLeft == -1) {
            pictureURL = null;
            return;
        } 
       */
        // Excluse cdm_results_list value=" part hence skip 29 characters
        cutLeft += 29;

        // Ending character is the closing double quotes
        int cutRight = response.indexOf("\"", cutLeft);

        // Extract string
        String URLlist = response.substring(cutLeft, cutRight);
        
        if(URLlist.equals("")) {
            pictureURL = "";
        } // End of if block
        
        else {
        // Store string and split it on "/"
        String[] ids = URLlist.split("/");
        String[] idlist = new String[ids.length];
        
        //Remove letters and angular brackets so that just the id is stored
        for(int i=0;i<ids.length;i++)
        {
            idlist[i] = ids[i].replaceAll("[^0-9]", "");
        } // End of for loop
        
        int id_size = idlist.length;
        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(id_size);
        pictureTag = idlist[randomInt];
        pictureURL = "http://digital.library.illinoisstate.edu/utils/ajaxhelper/?CISOROOT=icca&CISOPTR=" + pictureTag + "&action=2";  
        LOGGER.log(Level.INFO,""+pictureURL);
        } // End of else block
        
    } // End of void doICAASearch
    
    public void interestingPictureSize(){
        if(pictureURL.length()!=0){
            String imageURL = "http://digital.library.illinoisstate.edu/cdm/singleitem/collection/icca/id/"+pictureTag;
            String imageHTML = fetch(imageURL);
            
            int startIndex = imageHTML.indexOf("id=\"cdm_item_width\" value=\"")+"id=\"cdm_item_width\" value=\"".length(); // Get the index of just the width part
            int endIndex = imageHTML.indexOf("\"",startIndex);
            LOGGER.log(Level.INFO,""+startIndex);
            LOGGER.log(Level.INFO,""+endIndex);
            pictureWidth=imageHTML.substring(startIndex,endIndex);
            LOGGER.log(Level.INFO,""+pictureWidth);
            startIndex = imageHTML.indexOf("id=\"cdm_item_height\" value=\"")+"id=\"cdm_item_height\" value=\"".length();
            endIndex = imageHTML.indexOf("\"",startIndex);
            pictureHeight= imageHTML.substring(startIndex,endIndex);    
        }
    }
        String getmobileURL() { // Generating a separate URL for mobile
            if(pictureURL.length()!=0){
             int picwidth = Integer.parseInt(pictureWidth);
        if(picwidth>300){
            int res =30000/picwidth; // Adjusting the resolution as per the mobile screen
            pictureURL=pictureURL+"&DMSCALE="+res;
        }
        else{
            pictureURL=pictureURL+"&DMSCALE=100";
        }
            }
            else {
                pictureURL = "";
            }
            return pictureURL;
        } // End of getmobileURL
        
        String getdesktopURL() { // Generating a separate URL for desktop
            if(pictureURL.length()!=0){
            int picwidth=Integer.parseInt(pictureWidth);  
            if (picwidth>512){    
            int res=100;
            res=51200/picwidth;       // Adjusting the resolution if the image width is greater than 512         
            pictureURL = pictureURL+"&DMSCALE="+res+"&DMWIDTH=512"+"&DMHEIGHT="+pictureHeight;        
            }
            else{
            pictureURL = pictureURL+"DMSCALE=100";
            }
            }
            else {
              pictureURL = "";  
            }
            return pictureURL;
        } // End of getdesktopURL
      
    public String interestingPictureURL() {
        return (pictureURL);
    } 

    public String getPictureTag() {
        return (pictureTag);
    }
    public String getWidth() {
        return (pictureWidth);
    }
    public String getHeight() {
        return (pictureHeight);
    }
    

    /*
     * Make an HTTP request to a given URL
     * 
     * @param urlString The URL of the request
     * @return A string of the response from the HTTP GET.  This is identical
     * to what would be returned from using curl on the command line.
     */
    private String fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which 
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
        } catch (IOException e) {
            System.out.println("Error: Page cannot be load");
            // Do something reasonable.  This is left for students to do.
        }
        return response;
    }
}
