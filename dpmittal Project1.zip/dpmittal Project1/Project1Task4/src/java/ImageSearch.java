 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigInteger;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import java.util.logging.*;
import java.util.logging.Level;


/**
 *
 * @author Dishant Mittal
 */

@WebServlet(name = "ImageSearch",
        urlPatterns = {"/ImageSearch"})
public class ImageSearch extends HttpServlet {
    
    InterestingPictureModel ipm = null;  // The "business model" for this app

    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {
        ipm = new InterestingPictureModel();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String ua = request.getHeader("User-Agent");

        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
        
         String nextView;
         String inputstring = request.getParameter("inputstring");
         
         if(inputstring !=null) {
             
         request.setAttribute("ipstring", inputstring); // To display back the user input
          /*
         Removes all punctuations from the string.
         */
         String searchstring = inputstring.replaceAll("[^A-Za-z0-9]", ""); 
         
         ipm.doICAASearch(searchstring);
         ipm.interestingPictureSize();
         
         if(mobile == false) { //Display image for desktop screen
     
             request.setAttribute("pictureURL",ipm.getdesktopURL());
            // Pass the user search string (pictureTag) also to the view.
             request.setAttribute("pictureTag", ipm.getPictureTag());
             nextView = "result.jsp";
         
             // Here we are calculating the ration of height to width and based on that the correct height will be passed on to the main display jsp
         int w = Integer.parseInt(ipm.getWidth());
         int h = Integer.parseInt(ipm.getHeight());
         int height = 800*h/w;
         request.setAttribute("height", height);

         }
         else { //Display image for mobile screen
             request.setAttribute("pictureURL",ipm.getmobileURL());
            // Pass the user search string (pictureTag) also to the view.
             request.setAttribute("pictureTag", ipm.getPictureTag());
             nextView = "result.jsp";
         }
  
        } // End of outer if block
         
         else {
              nextView = "index.jsp";
         } // End of else block
                 
         RequestDispatcher view = request.getRequestDispatcher(nextView);
         view.forward(request, response);
         
    } // End of void doGet
    
} // End of ImageSearch
