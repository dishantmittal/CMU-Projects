
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import sun.misc.BASE64Encoder;


/**
 * @author Dishant Mittal
 * This servlet takes an input string from user and generates a hash code for it.
 */
@WebServlet(name = "ComputeHashes",
        urlPatterns = {"/ComputeHashes"})

public class ComputeHashes extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String ua = request.getHeader("User-Agent");
        String userinput = request.getParameter("inputstring");
        String encoding = request.getParameter("EncodingType");
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } // End of if block
        else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        } // End of else block
        
        if(encoding != null) {
        
        try {            
            MessageDigest mdvar = MessageDigest.getInstance(encoding);
            byte[] bytestring = mdvar.digest(userinput.getBytes());
            String hex = getHexString(bytestring);
            BASE64Encoder b64var= new BASE64Encoder();
            String b64 = b64var.encode(bytestring);
            
            request.setAttribute("userinput", userinput);
            request.setAttribute("EncodingType", encoding);
            request.setAttribute("hex", hex);
            request.setAttribute("b64", b64);
        } // End of try block
        
        catch (Exception e) {
            e.printStackTrace();
        } // End of catch block
        
        RequestDispatcher view = request.getRequestDispatcher("index.jsp");
        view.forward(request, response);
        } // End of if block
        
        else {
            RequestDispatcher view = request.getRequestDispatcher("index.jsp");
            view.forward(request, response);
        } // End of else block
       
    } // End of doGet
   
    public String getHexString(byte[] b) throws Exception {
        String result = "";
        for (int i=0; i < b.length; i++) {
        result += Integer.toString((b[i] & 0xff) + 0x100, 16).substring( 1 );
        } // End of for loop
        return result;
    } // End of getHexString

} // End of ComputeHashes
