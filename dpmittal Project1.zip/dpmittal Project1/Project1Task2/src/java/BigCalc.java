/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import java.math.BigDecimal;
import java.math.BigInteger;


/**
 * @author Dishant Mittal
 */

@WebServlet(name = "BigCalc",
        urlPatterns = {"/BigCalc"})

public class BigCalc extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String error = "The output cannot be calculated. Please make sure you have entered the values of X and Y and have selected an Operation. For power operation make sure Y is a positive integer.";
        request.setAttribute("error", error);
        try {
        String check = request.getParameter("X") + request.getParameter("Y");
        BigInteger X = new BigInteger(request.getParameter("X"));
        BigInteger Y = new BigInteger(request.getParameter("Y"));
        int p = Integer.parseInt(request.getParameter("Y"));
        BigInteger output;
        String result = "";
        String Operation = request.getParameter("Operation");
        request.setAttribute("Operation", Operation);

            if(check == null) {
                request.setAttribute("result", "Please make sure you have entered the values of X and Y.");
            } // End of if block
            
            else {
                switch (Operation) {
                    
                    case "Addition":
                        output = X.add(Y);
                        request.setAttribute("result", "For X = " + X + " and Y = " + Y + ", X + Y = " + output);
                        break;
                    case "Multiplication":
                        output = X.multiply(Y);
                        request.setAttribute("result", "For X = " + X + " and Y = " + Y + ", X * Y = " + output);
                        break;
                    case "Power":
                        if(p>0) {
                        output = X.pow(p);
                        request.setAttribute("result", "For X = " + X + " and Y = " + Y + ", X ^ Y = " + output);
                        }
                        else {
                        request.setAttribute("result", "The output cannot be calculated. Make sure Y is positive integer for Power Operation.");    
                        }
                        break;
                    case "Modulo":
                        output = X.mod(Y);
                        request.setAttribute("result", "For X = " + X + " and Y = " + Y + ", X mod Y = " + output);
                        break;
                    case "Relative-Prime":
                        if(X.gcd(Y).equals(new BigInteger("1"))) {
                            request.setAttribute("result", "For X = " + X + " and Y = " + Y + ", X and Y are relatively prime.");
                        }
                        else {
                            request.setAttribute("result", "For X = " + X + " and Y = " + Y + ", X and Y are not relatively prime.");
                        }
                        break;
                    case "Modulo-Inverse":
                        if(X.gcd(Y).equals(new BigInteger("1"))) {
                            output = X.modInverse(Y);
                            request.setAttribute("result", "For X = " + X + " and Y = " + Y + ", X^-1 mod Y = " + output);
                        }
                        else {
                            request.setAttribute("result", "For X = " + X + " and Y = " + Y + ", X-1 mod Y cannot be calculated as X and Y are not relatively prime.");
                        }
                        break;
                    default:
                        request.setAttribute("result", "Output cannot be calculated. Please ensure you have entered integer values for X and Y and have selected an Operation.");
                        break;
                } // End of switch block      
               
            } // End of else block
            
             RequestDispatcher view = request.getRequestDispatcher("index.jsp");
             view.forward(request, response);
        }
        catch (Exception e) {
            RequestDispatcher view = request.getRequestDispatcher("index.jsp");
            view.forward(request, response);
        }
      
    } // End of doGet

} // End of BigCalc
